

n = 0x00111111

if n & 0xff:
	print ("little endian")
else:
	print ("big endian")
