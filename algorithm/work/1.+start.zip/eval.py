a = eval("3+7/7+9-5*7-5")

print(a)