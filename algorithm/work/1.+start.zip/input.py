import sys
sys.stdin = open("input.txt", "r")

T = int(input())
r, c = map(int, input().split(' '))
arr = [list(map(int, input())) for _ in range(r)]

print (T)
print ("{} {}".format(r,c))
for i in range(r):
	for j in range(c):
		print(arr[i][j], end="")
	print()
